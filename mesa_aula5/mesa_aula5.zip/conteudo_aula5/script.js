let body = document.querySelector('body')
function ativar(){
    body.classList.toggle('dark')
}
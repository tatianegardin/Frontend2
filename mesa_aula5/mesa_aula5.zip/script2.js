let divTigre = document.createElement('div');
let divLeao = document.createElement('div')
let container = document.querySelector('.container');

divTigre.innerHTML = `
<div class="item">
    <img src="./imagens/tiger.jpg" alt>
    <h2>O tigre</h2>
    <p>
    O tigre (Panthera tigris) é uma das espécies da subfamília Pantherinae (família Felidae)
    pertencente ao gênero Panthera. É encontrado de forma nativa apenas no continente asiático; é um predador
    carnívoro e
    é a maior espécie de felino do mundo junto com o leão.
    </p>
</div>`;

divLeao.innerHTML = `   
<div class="item">
    <img src="./imagens/leon.jpg">
    <h2>O leão</h2>
    <p>
    O leão (Panthera leo) é um mamífero carnívoro da família dos felinos é uma das cinco espécies do gênero
    gênero Panthera. Os leões selvagens vivem em populações cada vez mais dispersas e fragmentadas na África
    subsahariana
    (com exceção das regiões florestais e das regiões de selva da Bacia do Congo) e uma pequena área do noroeste da
    Índia.
    </p>
</div>`


function ativar(){
    container.appendChild(divLeao)
    container.appendChild(divTigre);
}